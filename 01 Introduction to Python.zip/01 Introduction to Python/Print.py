'''
Your task is to print a statement that outputs the message "Coding Ninjas".
'''

print( "Coding Ninjas")
