'''
Problem statement
Your task is to print these statement:

I'm learning Python.
Python is a high-level language.
'''

print("I’m learning Python.")
print("Python is a high-level language.")
